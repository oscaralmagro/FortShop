plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.oscaralmagro.fortshop"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.oscaralmagro.fortshop"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "3.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
