package com.oscaralmagro.fortshop

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.JsonReader
import android.util.JsonToken
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Calendar
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.obj(k: String): Map<String, Any?>? = this[k] as? Map<String, Any?>

@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.arr(k: String): List<Map<String, Any?>>? =
    (this[k] as? List<*>)?.filterIsInstance<Map<*, *>>()?.map { it as Map<String, Any?> }

fun Map<String, Any?>.str(k: String): String? = this[k] as? String

fun Map<String, Any?>.num(k: String): Int? = (this[k] as? Number)?.toInt()

data class Entry(
    val id: String,
    val name: String,
    val names: List<String>,
    val price: Int,
    val oldPrice: Int?,
    val section: String,
    val rank: Int?,
    val image: String,
    val type: String,
    val out: String
)

@Suppress("UNCHECKED_CAST")
object Api {
    private const val BASE = "https://fortnite-api.com/v2"

    private fun readAny(r: JsonReader): Any? = when (r.peek()) {
        JsonToken.BEGIN_OBJECT -> {
            val m = HashMap<String, Any?>()
            r.beginObject()
            while (r.hasNext()) {
                val k = r.nextName()
                m[k] = readAny(r)
            }
            r.endObject()
            m
        }
        JsonToken.BEGIN_ARRAY -> {
            val l = ArrayList<Any?>()
            r.beginArray()
            while (r.hasNext()) l.add(readAny(r))
            r.endArray()
            l
        }
        JsonToken.STRING -> r.nextString()
        JsonToken.NUMBER -> r.nextDouble()
        JsonToken.BOOLEAN -> r.nextBoolean()
        else -> {
            r.nextNull()
            null
        }
    }

    private fun open(path: String): HttpURLConnection {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("User-Agent", "FortShop/1.0")
        c.setRequestProperty("Accept", "application/json")
        return c
    }

    private fun root(path: String): Map<String, Any?> {
        val c = open(path)
        try {
            JsonReader(InputStreamReader(c.inputStream, "UTF-8")).use { r ->
                return (readAny(r) as? Map<String, Any?>) ?: emptyMap()
            }
        } finally {
            c.disconnect()
        }
    }

    fun stream(path: String, onItem: (Map<String, Any?>) -> Unit) {
        val c = open(path)
        try {
            JsonReader(InputStreamReader(c.inputStream, "UTF-8")).use { r ->
                r.beginObject()
                while (r.hasNext()) {
                    if (r.nextName() == "data" && r.peek() == JsonToken.BEGIN_ARRAY) {
                        r.beginArray()
                        while (r.hasNext()) {
                            val item = readAny(r) as? Map<String, Any?>
                            if (item != null) onItem(item)
                        }
                        r.endArray()
                    } else {
                        r.skipValue()
                    }
                }
                r.endObject()
            }
        } finally {
            c.disconnect()
        }
    }

    fun raw(path: String): String {
        val c = open(path)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun fetchShop(lang: String = "es"): List<Entry> {
        val data = root("/shop?language=" + lang).obj("data") ?: return emptyList()
        val entries = data.arr("entries") ?: return emptyList()
        return entries.map { e ->
            val names = ArrayList<String>()
            e.obj("bundle")?.str("name")?.let { names.add(it) }
            e.arr("brItems")?.forEach { i -> i.str("name")?.let { names.add(it) } }
            e.arr("tracks")?.forEach { i -> i.str("title")?.let { names.add(it) } }
            e.arr("instruments")?.forEach { i -> i.str("name")?.let { names.add(it) } }
            e.arr("cars")?.forEach { i -> i.str("name")?.let { names.add(it) } }
            val layout = e.obj("layout")
            val price = e.num("finalPrice") ?: 0
            val regular = e.num("regularPrice")
            val image = e.obj("newDisplayAsset")?.arr("renderImages")?.firstOrNull()?.str("image")
                ?: e.obj("bundle")?.str("image")
                ?: e.arr("brItems")?.firstOrNull()?.obj("images")?.str("icon")
                ?: e.arr("tracks")?.firstOrNull()?.str("albumArt")
                ?: e.arr("instruments")?.firstOrNull()?.obj("images")?.str("small")
                ?: e.arr("cars")?.firstOrNull()?.obj("images")?.str("small")
                ?: ""
            Entry(
                id = e.str("offerId") ?: (names.firstOrNull() ?: ""),
                name = names.firstOrNull() ?: "Objeto",
                names = names,
                price = price,
                oldPrice = if (regular != null && regular > price) regular else null,
                section = layout?.str("name") ?: e.obj("section")?.str("name") ?: "Otros",
                rank = layout?.num("rank"),
                image = image,
                type = if (!e.arr("tracks").isNullOrEmpty() || !e.arr("instruments").isNullOrEmpty()) "festival"
                else if (!e.arr("cars").isNullOrEmpty()) "racing" else "br",
                out = e.str("outDate") ?: ""
            )
        }
    }

    fun shopJson(lang: String): String {
        val arr = JSONArray()
        for (e in fetchShop(lang)) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("name", e.name)
            o.put("names", JSONArray(e.names))
            o.put("price", e.price)
            o.put("oldPrice", e.oldPrice ?: JSONObject.NULL)
            o.put("section", e.section)
            o.put("rank", e.rank ?: JSONObject.NULL)
            o.put("image", e.image)
            o.put("type", e.type)
            o.put("out", e.out)
            arr.put(o)
        }
        return arr.toString()
    }
}

object Catalog {
    private fun file(ctx: Context, lang: String) = File(ctx.filesDir, "catalog_" + lang + ".json")

    fun read(ctx: Context, lang: String): String {
        val f = file(ctx, lang)
        return if (f.exists()) f.readText() else "[]"
    }

    fun ensure(ctx: Context, lang: String) {
        val f = file(ctx, lang)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < 24L * 3600L * 1000L) return
        val out = JSONArray()
        fun add(n: String?, t: String, r: String, img: String) {
            if (!n.isNullOrBlank()) out.put(JSONArray().put(n).put(t).put(r).put(img))
        }
        try {
            Api.stream("/cosmetics/br?language=" + lang) { i ->
                add(
                    i.str("name"),
                    i.obj("type")?.str("displayValue") ?: "Objeto",
                    i.obj("rarity")?.str("displayValue") ?: "",
                    i.obj("images")?.str("smallIcon") ?: i.obj("images")?.str("icon") ?: ""
                )
            }
        } catch (e: Exception) {
        }
        try {
            Api.stream("/cosmetics/tracks?language=" + lang) { i ->
                add(i.str("title"), "Pista de jam", i.str("artist") ?: "", i.str("albumArt") ?: "")
            }
        } catch (e: Exception) {
        }
        try {
            Api.stream("/cosmetics/instruments?language=" + lang) { i ->
                add(i.str("name"), "Instrumento", "", i.obj("images")?.str("small") ?: "")
            }
        } catch (e: Exception) {
        }
        try {
            Api.stream("/cosmetics/cars?language=" + lang) { i ->
                add(i.str("name"), "Coche", "", i.obj("images")?.str("small") ?: "")
            }
        } catch (e: Exception) {
        }
        if (out.length() > 0) {
            val tmp = File(f.path + ".tmp")
            tmp.writeText(out.toString())
            tmp.renameTo(f)
        }
    }
}

object Notifier {
    fun show(ctx: Context, title: String, text: String, id: Int = 1) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("shop", "Avisos de la tienda", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, "shop")
            .setSmallIcon(R.drawable.ic_fg)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

object Checker {
    @Synchronized
    fun run(ctx: Context): Boolean {
        val prefs = ctx.getSharedPreferences("fortshop", Context.MODE_PRIVATE)
        val lang = prefs.getString("lang", "es") ?: "es"
        val entries = Api.fetchShop(lang)
        if (entries.isEmpty()) return false
        val ids = entries.map { it.id }.sorted().joinToString(",")
        val last = prefs.getString("lastIds", null)
        prefs.edit().putString("lastIds", ids).apply()
        if (last == null || last == ids) return true

        if (prefs.getBoolean("notifyDaily", false)) {
            val before = last.split(",").toHashSet()
            val fresh = entries.count { !before.contains(it.id) }
            Notifier.show(ctx, "La tienda ha cambiado", fresh.toString() + " objetos nuevos hoy", 2)
        }

        val wish = HashSet<String>()
        try {
            val a = JSONArray(prefs.getString("wish", "[]") ?: "[]")
            for (i in 0 until a.length()) wish.add(norm(a.getString(i)))
        } catch (e: Exception) {
        }
        val hits = entries.filter { en -> en.names.any { wish.contains(norm(it)) } }
        if (hits.isNotEmpty()) {
            val text = hits.joinToString(", ") { it.name + " (" + it.price + " paVos)" }
            Notifier.show(ctx, "¡Ya está en la tienda!", text, 1)
        }
        return true
    }
}

class ShopWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): ListenableWorker.Result {
        return try {
            if (Checker.run(applicationContext)) ListenableWorker.Result.success()
            else ListenableWorker.Result.retry()
        } catch (e: Exception) {
            ListenableWorker.Result.retry()
        }
    }
}

object Alarms {
    private const val WINDOW_MIN = 10L

    fun nextTrigger(now: Long): Long {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 5)
        cal.set(Calendar.MILLISECOND, 0)
        val base = cal.timeInMillis
        val windowEnd = base + WINDOW_MIN * 60_000L
        return when {
            now < base -> base
            now < windowEnd -> now + 60_000L
            else -> base + 24L * 3600_000L
        }
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val t = nextTrigger(System.currentTimeMillis())
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        Alarms.schedule(app)
        val pending = goAsync()
        thread {
            try {
                Checker.run(app)
            } catch (e: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Alarms.schedule(context.applicationContext)
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(true)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.setBackgroundColor(0xFF15112B.toInt())
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        schedule()
        Alarms.schedule(applicationContext)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun schedule() {
        val c = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val wm = WorkManager.getInstance(applicationContext)
        wm.enqueueUniquePeriodicWork(
            "shop-check",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ShopWorker>(15, TimeUnit.MINUTES).setConstraints(c).build()
        )
        wm.enqueueUniqueWork(
            "shop-first",
            ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<ShopWorker>().setConstraints(c).build()
        )
    }

    private fun push(fn: String, arg: String?) {
        val a = if (arg == null) "" else JSONObject.quote(arg)
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
        runOnUiThread { web.evaluateJavascript("window.$fn($a)", null) }
    }

    private fun pushRaw(id: String, json: String) {
        val a = JSONObject.quote(id)
        val b = JSONObject.quote(json).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
        runOnUiThread { web.evaluateJavascript("window.onRaw(" + a + "," + b + ")", null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun shop(lang: String) {
            thread {
                val j = try {
                    Api.shopJson(if (lang == "en") "en" else "es")
                } catch (e: Exception) {
                    "[]"
                }
                push("onShop", j)
            }
        }

        @JavascriptInterface
        fun refreshCatalog(lang: String) {
            thread {
                try {
                    Catalog.ensure(applicationContext, if (lang == "en") "en" else "es")
                } catch (e: Exception) {
                }
                push("onCatalogReady", null)
            }
        }

        @JavascriptInterface
        fun catalog(lang: String): String =
            Catalog.read(applicationContext, if (lang == "en") "en" else "es")

        @JavascriptInterface
        fun get(id: String, path: String) {
            val ok = path.startsWith("/news/") || path.startsWith("/map") || path.startsWith("/cosmetics/new")
            thread {
                val j = try {
                    if (ok) Api.raw(path) else "null"
                } catch (e: Exception) {
                    "null"
                }
                pushRaw(id, j)
            }
        }

        @JavascriptInterface
        fun setPrefs(json: String) {
            try {
                val o = JSONObject(json)
                getSharedPreferences("fortshop", Context.MODE_PRIVATE).edit()
                    .putString("lang", if (o.optString("lang") == "en") "en" else "es")
                    .putBoolean("notifyDaily", o.optBoolean("notify", false))
                    .apply()
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun setWish(json: String) {
            getSharedPreferences("fortshop", Context.MODE_PRIVATE).edit().putString("wish", json).apply()
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            if (u.startsWith("https://")) {
                runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
            }
        }
    }
}
