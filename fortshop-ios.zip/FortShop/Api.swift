import Foundation

func norm(_ s: String) -> String {
    return s.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil).lowercased()
}

private func dict(_ x: Any?) -> [String: Any]? { return x as? [String: Any] }
private func list(_ x: Any?) -> [[String: Any]] { return (x as? [[String: Any]]) ?? [] }
private func str(_ x: Any?) -> String? { return x as? String }
private func int(_ x: Any?) -> Int? { return (x as? NSNumber)?.intValue }

enum Api {
    static let base = "https://fortnite-api.com/v2"

    static func url(_ path: String) -> URL {
        let full = path.hasPrefix("/v1/") ? "https://fortnite-api.com" + path : base + path
        return URL(string: full)!
    }

    static func rawData(_ path: String) async throws -> Data {
        var req = URLRequest(url: url(path))
        req.timeoutInterval = 90
        req.setValue("FortShop/1.0", forHTTPHeaderField: "User-Agent")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, _) = try await URLSession.shared.data(for: req)
        return data
    }

    static func raw(_ path: String) async throws -> String {
        let d = try await rawData(path)
        return String(data: d, encoding: .utf8) ?? "null"
    }

    static func json(_ path: String) async throws -> Any {
        let d = try await rawData(path)
        return try JSONSerialization.jsonObject(with: d, options: [.fragmentsAllowed])
    }

    /// Misma estructura que Api.shopJson de Android.
    static func shop(_ lang: String) async throws -> [[String: Any]] {
        let root = try await json("/shop?language=" + lang)
        guard let data = dict(dict(root)?["data"]), let entries = data["entries"] as? [[String: Any]] else { return [] }
        return entries.map { (e: [String: Any]) -> [String: Any] in
            let br = list(e["brItems"]), tracks = list(e["tracks"]), inst = list(e["instruments"]), cars = list(e["cars"])
            let bundle = dict(e["bundle"])
            var names: [String] = []
            if let n = str(bundle?["name"]) { names.append(n) }
            br.forEach { if let n = str($0["name"]) { names.append(n) } }
            tracks.forEach { if let n = str($0["title"]) { names.append(n) } }
            inst.forEach { if let n = str($0["name"]) { names.append(n) } }
            cars.forEach { if let n = str($0["name"]) { names.append(n) } }

            var items: [[String: Any]] = []
            func add(_ n: String?, _ t: String, _ i: String?, _ id: String?, _ g: String) {
                if let n = n, !n.trimmingCharacters(in: .whitespaces).isEmpty {
                    items.append(["n": n, "t": t, "i": i ?? "", "id": id ?? "", "g": g])
                }
            }
            br.forEach { b in
                let im = dict(b["images"])
                add(str(b["name"]), str(dict(b["type"])?["displayValue"]) ?? "", str(im?["icon"]) ?? str(im?["smallIcon"]), str(b["id"]), "br")
            }
            tracks.forEach { add(str($0["title"]), "Pista de jam", str($0["albumArt"]), str($0["id"]), "tracks") }
            inst.forEach { add(str($0["name"]), "Instrumento", str(dict($0["images"])?["small"]), str($0["id"]), "instruments") }
            cars.forEach { add(str($0["name"]), "Coche", str(dict($0["images"])?["small"]), str($0["id"]), "cars") }

            let layout = dict(e["layout"])
            let price = int(e["finalPrice"]) ?? 0
            let regular = int(e["regularPrice"])
            let image: String = str(list(dict(e["newDisplayAsset"])?["renderImages"]).first?["image"])
                ?? str(bundle?["image"])
                ?? str(dict(br.first?["images"])?["icon"])
                ?? str(tracks.first?["albumArt"])
                ?? str(dict(inst.first?["images"])?["small"])
                ?? str(dict(cars.first?["images"])?["small"])
                ?? ""
            let festival = !tracks.isEmpty || !inst.isEmpty
            var o: [String: Any] = [:]
            o["id"] = str(e["offerId"]) ?? (names.first ?? "")
            o["name"] = names.first ?? "Objeto"
            o["names"] = names
            o["price"] = price
            o["oldPrice"] = (regular != nil && regular! > price) ? (regular! as Any) : (NSNull() as Any)
            o["section"] = str(layout?["name"]) ?? str(dict(e["section"])?["name"]) ?? "Otros"
            o["rank"] = int(layout?["rank"]).map { $0 as Any } ?? (NSNull() as Any)
            o["image"] = image
            o["type"] = festival ? "festival" : (!cars.isEmpty ? "racing" : "br")
            o["out"] = str(e["outDate"]) ?? ""
            o["cid"] = str(br.first?["id"]) ?? ""
            o["bn"] = str(bundle?["name"]) ?? ""
            o["items"] = items
            return o
        }
    }

    // MARK: Catálogo

    private static func catalogFile(_ lang: String) -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("catalog2_" + lang + ".json")
    }

    static func cachedCatalog(_ lang: String) -> String? {
        return try? String(contentsOf: catalogFile(lang), encoding: .utf8)
    }

    private static func catalogRow(_ g: String, _ i: [String: Any]) -> [Any]? {
        guard let name = str(i["name"]) ?? str(i["title"]), !name.trimmingCharacters(in: .whitespaces).isEmpty else { return nil }
        let tv = dict(i["type"])
        let typeVal = (str(tv?["value"]) ?? "") + " " + (str(tv?["backendValue"]) ?? "")
        var label: String
        switch g {
        case "tracks": label = "Pista de jam"
        case "instruments": label = "Instrumento"
        case "cars": label = "Coche"
        case "legoKits": label = "Kit LEGO"
        case "beans": label = "Bean"
        case "br", "": label = str(tv?["displayValue"]) ?? "Objeto"
        default: label = str(tv?["displayValue"]) ?? (g.prefix(1).uppercased() + g.dropFirst())
        }
        if typeVal.lowercased().contains("sprite") && !label.lowercased().contains("sprite") { label = "Sprite" }
        let im = dict(i["images"])
        let image = str(im?["smallIcon"]) ?? str(im?["icon"]) ?? str(im?["small"]) ?? str(im?["large"]) ?? str(i["albumArt"]) ?? ""
        let rarity = str(dict(i["rarity"])?["displayValue"]) ?? str(i["artist"]) ?? ""
        return [name, label, rarity, image, str(i["id"]) ?? "", g]
    }

    private static func collect(_ path: String, into out: inout [[Any]], skipLego: Bool) async {
        guard let root = try? await json(path), let data = dict(root)?["data"] else { return }
        if let arr = data as? [[String: Any]] {
            for i in arr { if let r = catalogRow("", i) { out.append(r) } }
        } else if let groups = data as? [String: Any] {
            for (g, v) in groups {
                if skipLego && g == "lego" { continue }
                for i in list(v) { if let r = catalogRow(g, i) { out.append(r) } }
            }
        }
    }

    /// Devuelve el JSON del catálogo (lo descarga si la caché tiene más de 24 h).
    static func ensureCatalog(_ lang: String) async -> String? {
        let f = catalogFile(lang)
        if let attrs = try? FileManager.default.attributesOfItem(atPath: f.path),
           let m = attrs[.modificationDate] as? Date, Date().timeIntervalSince(m) < 86400,
           let s = cachedCatalog(lang) { return s }
        var out: [[Any]] = []
        await collect("/cosmetics?language=" + lang, into: &out, skipLego: true)
        if out.isEmpty {
            for g in ["br", "tracks", "instruments", "cars"] {
                var part: [[Any]] = []
                await collect("/cosmetics/" + g + "?language=" + lang, into: &part, skipLego: false)
                for var r in part { r[5] = g; out.append(r) }
            }
        }
        if out.isEmpty { return cachedCatalog(lang) }
        if let d = try? JSONSerialization.data(withJSONObject: out), let s = String(data: d, encoding: .utf8) {
            try? d.write(to: f, options: .atomic)
            return s
        }
        return cachedCatalog(lang)
    }
}
