import SwiftUI
import WebKit
import UIKit

private let shim = """
(function(){
  function post(fn,arg){window.webkit.messageHandlers.native.postMessage({fn:fn,arg:(arg===undefined?null:arg)})}
  window.__cat=window.__cat||{};
  window.Android={
    shop:function(l){post('shop',l)},
    refreshCatalog:function(l){post('refreshCatalog',l)},
    catalog:function(l){return window.__cat[l]||'[]'},
    get:function(id,p){post('get',{id:id,path:p})},
    setPrefs:function(j){post('setPrefs',j)},
    setWish:function(j){post('setWish',j)},
    mail:function(){post('mail')},
    openUrl:function(u){post('openUrl',u)}
  };
})();
"""

/// Convierte un String en un literal de JavaScript seguro.
func jsLiteral(_ s: String) -> String {
    guard let d = try? JSONSerialization.data(withJSONObject: [s], options: []),
          let t = String(data: d, encoding: .utf8) else { return "\"\"" }
    return String(t.dropFirst().dropLast())
}

final class Bridge: NSObject, WKScriptMessageHandler, WKURLSchemeHandler {
    weak var web: WKWebView?

    // Sirve index.html desde el paquete con un origen estable (app://local) para que localStorage no se pierda.
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url,
              let file = Bundle.main.url(forResource: "index", withExtension: "html"),
              let data = try? Data(contentsOf: file) else {
            urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist))
            return
        }
        let resp = URLResponse(url: url, mimeType: "text/html", expectedContentLength: data.count, textEncodingName: "utf-8")
        urlSchemeTask.didReceive(resp)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    private func js(_ code: String) {
        DispatchQueue.main.async { self.web?.evaluateJavaScript(code, completionHandler: nil) }
    }

    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let body = m.body as? [String: Any], let fn = body["fn"] as? String else { return }
        let arg = body["arg"]
        switch fn {
        case "shop":
            let lang = (arg as? String) == "en" ? "en" : "es"
            Task {
                var json = "[]"
                if let list = try? await Api.shop(lang),
                   let d = try? JSONSerialization.data(withJSONObject: list),
                   let s = String(data: d, encoding: .utf8) { json = s }
                self.js("window.onShop(" + jsLiteral(json) + ")")
            }
        case "refreshCatalog":
            let lang = (arg as? String) == "en" ? "en" : "es"
            Task {
                if let s = await Api.ensureCatalog(lang) {
                    self.js("window.__cat=window.__cat||{};window.__cat['" + lang + "']=" + jsLiteral(s))
                }
                self.js("window.onCatalogReady()")
            }
        case "get":
            guard let o = arg as? [String: Any], let id = o["id"] as? String, let path = o["path"] as? String else { return }
            let ok = path.hasPrefix("/news/") || path.hasPrefix("/v1/map") || path.hasPrefix("/cosmetics/new") || path.hasPrefix("/cosmetics/br/")
            Task {
                var j = "null"
                if ok, let s = try? await Api.raw(path) { j = s }
                self.js("window.onRaw(" + jsLiteral(id) + "," + jsLiteral(j) + ")")
            }
        case "setPrefs":
            guard let s = arg as? String, let d = s.data(using: .utf8),
                  let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return }
            let lang = (o["lang"] as? String) == "en" ? "en" : "es"
            let notify = (o["notify"] as? Bool) ?? false
            UserDefaults.standard.set(lang, forKey: "lang")
            UserDefaults.standard.set(notify, forKey: "notifyDaily")
            Notifier.setDaily(enabled: notify, lang: lang)
        case "setWish":
            if let s = arg as? String { UserDefaults.standard.set(s, forKey: "wish") }
        case "mail":
            if let u = URL(string: "mailto:hamammi1140@gmail.com?subject=FortShop%20-%20Sugerencias") {
                DispatchQueue.main.async { UIApplication.shared.open(u) }
            }
        case "openUrl":
            if let s = arg as? String, s.hasPrefix("https://"), let u = URL(string: s) {
                DispatchQueue.main.async { UIApplication.shared.open(u) }
            }
        default: break
        }
    }
}

struct WebContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let bridge = Bridge()
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(bridge, forURLScheme: "app")

        var source = shim
        for lang in ["es", "en"] {
            if let c = Api.cachedCatalog(lang) {
                source += "\nwindow.__cat['" + lang + "']=" + jsLiteral(c) + ";"
            }
        }
        let uc = WKUserContentController()
        uc.add(bridge, name: "native")
        uc.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = uc

        let web = WKWebView(frame: .zero, configuration: cfg)
        bridge.web = web
        context.coordinator.bridge = bridge
        let bg = UIColor(red: 0.082, green: 0.067, blue: 0.169, alpha: 1)
        web.isOpaque = false
        web.backgroundColor = bg
        web.scrollView.backgroundColor = bg
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = true
        web.load(URLRequest(url: URL(string: "app://local/index.html")!))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator() }
    final class Coordinator { var bridge: Bridge? }
}
