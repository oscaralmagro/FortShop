import Foundation
import UserNotifications
import BackgroundTasks

enum Notifier {
    static func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    static func show(_ title: String, _ text: String, id: String) {
        let c = UNMutableNotificationContent()
        c.title = title
        c.body = text
        c.sound = .default
        let r = UNNotificationRequest(identifier: id, content: c, trigger: nil)
        UNUserNotificationCenter.current().add(r)
    }

    /// Aviso diario a las 00:01 UTC (hora a la que cambia la tienda). Fiable porque es una notificación local programada.
    static func setDaily(enabled: Bool, lang: String) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["daily"])
        guard enabled else { return }
        let c = UNMutableNotificationContent()
        c.title = lang == "en" ? "The shop has changed" : "La tienda ha cambiado"
        c.body = lang == "en" ? "New items are available today." : "Hay objetos nuevos hoy."
        c.sound = .default
        var comps = DateComponents()
        comps.timeZone = TimeZone(identifier: "UTC")
        comps.hour = 0
        comps.minute = 1
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: true)
        center.add(UNNotificationRequest(identifier: "daily", content: c, trigger: trigger))
    }
}

enum Checker {
    static let defaults = UserDefaults.standard

    @discardableResult
    static func run() async -> Bool {
        let lang = defaults.string(forKey: "lang") ?? "es"
        guard let entries = try? await Api.shop(lang), !entries.isEmpty else { return false }
        let ids = entries.compactMap { $0["id"] as? String }.sorted().joined(separator: ",")
        let last = defaults.string(forKey: "lastIds")
        defaults.set(ids, forKey: "lastIds")
        guard let prev = last, prev != ids else { return true }
        _ = prev

        var wish = Set<String>()
        if let data = (defaults.string(forKey: "wish") ?? "[]").data(using: .utf8),
           let a = try? JSONSerialization.jsonObject(with: data) as? [String] {
            a.forEach { wish.insert(norm($0)) }
        }
        let hits = entries.filter { e in
            let names = (e["names"] as? [String]) ?? []
            return names.contains { wish.contains(norm($0)) }
        }
        if !hits.isEmpty {
            let text = hits.map { h in
                "\(h["name"] as? String ?? "") (\(h["price"] as? Int ?? 0) paVos)"
            }.joined(separator: ", ")
            Notifier.show("¡Ya está en la tienda!", text, id: "wish")
        }
        return true
    }
}

enum Background {
    static let id = "com.oscaralmagro.fortshop.refresh"

    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: id, using: nil) { task in
            schedule()
            let work = Task {
                let ok = await Checker.run()
                task.setTaskCompleted(success: ok)
            }
            task.expirationHandler = { work.cancel() }
        }
    }

    static func schedule() {
        let req = BGAppRefreshTaskRequest(identifier: id)
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "UTC")!
        var next = cal.startOfDay(for: Date())
        next = cal.date(byAdding: .minute, value: 2, to: next)!
        if next <= Date() { next = cal.date(byAdding: .day, value: 1, to: next)! }
        req.earliestBeginDate = next
        try? BGTaskScheduler.shared.submit(req)
    }
}
